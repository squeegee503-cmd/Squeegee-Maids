// EDIT THIS FILE to change logo, wording, phone, and content.

export const site = {
  brandName: "Squeegee",
  brandTagline: "MAIDS",

  phone: "(971) 302-4242",
  phoneHref: "tel:+19713024242",
  bookUrl: "https://squeegeemaids.fieldd.co/",
  address: {
    line1: "Squeegee Maids",
    line2: "Serving all of Portland, OR",
    line3: "& surrounding cities",
  },

  // Hero
  heroBadge: "Serving the Portland Metro",
  heroTitleA: "Fast, Reliable Home Cleaning",
  heroTitleB: "in Portland.",
  heroSub:
    "Home, office, or Airbnb — Squeegee Maids brings a background-checked, insured cleaning team to your door. Eco-friendly products, flexible scheduling, no contracts.",
  heroBullets: [
    "Insured & Background-Checked",
    "Eco-Friendly Products",
    "Same-Day Availability",
  ],

  trustBar: [
    "Insured & Background-Checked",
    "Eco-Friendly Products",
    "Flexible Scheduling",
    "Trusted Since 2020",
  ],

  reviewsHeading: "Portland Loves a Squeegee-Clean Home",
  reviewsRating: "4.9",
  reviewsCount: "Hundreds of happy Portland homes",
  reviews: [
    { quote: "My apartment has never looked better. Team was on time, friendly, and every corner was spotless when they left.", name: "Rachel M." },
    { quote: "Booked a move-out clean and got my full deposit back. Landlord even asked who I used! Highly recommend.", name: "David K." },
    { quote: "We run an Airbnb and Squeegee Maids has been a game changer. Guests always mention how clean the place is.", name: "Priya S." },
    { quote: "Eco-friendly products that actually work. My kitchen sparkles and the house smells fresh, not like chemicals.", name: "Meredith L." },
    { quote: "Reliable, thorough, and super easy to schedule. They've been cleaning our office weekly for over a year.", name: "Jordan T." },
    { quote: "First deep clean took my breath away. I forgot my baseboards were white!", name: "Alicia R." },
  ],

  servicesEyebrow: "Services & Pricing",
  servicesHeading: "Pick Your Level of Clean",
  services: [
    {
      title: "Residential Cleaning",
      desc: "Keep your home fresh with regular or one-time cleanings.",
      bullets: ["Dust, vacuum & mop", "Kitchen & bathrooms deep-cleaned", "Weekly, bi-weekly or monthly", "Perfect for busy households"],
      badge: null as string | null,
    },
    {
      title: "Airbnb Turnovers",
      desc: "Guest-ready every stay. Fast turnarounds, spotless results.",
      bullets: ["Linens & bedding refresh", "Sanitize bath & kitchen", "Restock essentials on request", "Same-day turnovers available"],
      badge: "Most Popular",
    },
    {
      title: "Eco friendly Products",
      desc: "Detailed deep clean so you start (or leave) with a spotless home.",
      bullets: ["Fresh Start for Your New Home", "Leave a Lasting Impression", "Maximize deposit returns", "Ready for the next owner"],
      badge: null,
    },
  ],
  servicesFooter:
    "Also offering: commercial & office cleaning, eco-friendly deep cleans, one-time refresh, and occasional cleaning.",

  stepsEyebrow: "How It Works",
  stepsHeading: "Effortless Cleaning in 3 Steps",
  steps: [
    { n: "01", title: "Book Your Cleaning", desc: "Schedule online in minutes, or call and text us for the best time." },
    { n: "02", title: "Personalized Package", desc: "Choose a plan built for your home — recurring maintenance or a full deep clean." },
    { n: "03", title: "Enjoy Your Fresh Space", desc: "Come home to a sparkling clean space, ready to be enjoyed." },
  ],

  ceramicEyebrow: "Deep Clean Difference",
  ceramicHeading: "Cleanings That Stay Clean for 10 Days or More.",
  ceramicBody:
    "Our detailed deep cleans go beyond the surface — inside appliances, under furniture, and every baseboard. Eco-friendly, non-toxic products that are safe for kids, pets, and the planet.",
  ceramicBullets: [
    "Non-toxic, pet & child-safe products",
    "Detailed kitchen & bathroom deep clean",
    "Interior windows, baseboards & vents",
  ],

  whyEyebrow: "Why Portland",
  whyHeading: "Why Portland Books Squeegee Maids",
  whyItems: [
    { title: "Insured & Trusted", desc: "Every cleaner is background-checked, insured, and trained to protect your home." },
    { title: "Eco-Friendly", desc: "Non-toxic products that are safe for kids, pets, and the environment." },
    { title: "Flexible Scheduling", desc: "Weekly, bi-weekly, monthly, or one-time — we work around your calendar." },
    { title: "Local Since 2020", desc: "Locally owned and Portland-proud. We know your neighborhood." },
    { title: "No Surprises", desc: "Transparent pricing with no contracts and no hidden fees." },
    { title: "Satisfaction Guaranteed", desc: "Not happy with a spot? Tell us and we'll come back and re-clean it free." },
  ],

  areaEyebrow: "Service Area",
  areaHeading: "House Cleaning in Portland Neighborhoods",
  areaBody: "From downtown condos to Sellwood bungalows, we serve homes and businesses across Portland and nearby cities.",
  areaCities: [
    "Portland", "Beaverton", "Hillsboro", "Tigard", "Lake Oswego", "Vancouver",
    "Gresham", "Happy Valley", "Tualatin", "Milwaukie", "Oregon City", "Bethany",
    "Aloha", "Cedar Mill", "Cedar Hills", "Forest Grove", "Cornelius", "Camas",
    "Troutdale", "Fairview", "West Linn", "Clackamas", "North Plains", "Banks",
    "Scappoose", "Damascus", "Gladstone", "Oak Grove", "Jennings Lodge",
    "Hazeldale", "Bull Mountain", "Rock Creek", "Bonny Slope", "Raleigh Hills",
    "Garden Home", "Sauvie Island",
  ],

  faqEyebrow: "FAQ",
  faqHeading: "Answers Before You Ask",
  faqs: [
    { q: "What home cleaning services do you offer?", a: "Residential, commercial, and Airbnb cleaning — each tailored to your unique needs, from maintenance cleans to detailed deep cleans." },
    { q: "Can I customize my cleaning plan?", a: "Absolutely. All we need is access to electricity and water — we carry extension cords up to 100 feet if needed." },
    { q: "Do you offer same-day cleaning?", a: "Yes, subject to availability. Reach out as soon as possible and we'll do our best to fit you in." },
    { q: "What areas do you serve?", a: "We serve the entire Portland metro and surrounding cities, including Portland, Beaverton, Hillsboro, Tigard, Lake Oswego, Vancouver, Gresham, Happy Valley, Tualatin, Milwaukie, Oregon City, Bethany, Aloha, Cedar Mill, Cedar Hills, Forest Grove, Cornelius, Camas, Troutdale, Fairview, West Linn, Clackamas, North Plains, Banks, Scappoose, Damascus, Gladstone, Oak Grove, Jennings Lodge, Hazeldale, Bull Mountain, Rock Creek, Bonny Slope, Raleigh Hills, Garden Home, and Sauvie Island. Not sure if we reach you? Call or text to confirm." },
    { q: "Are your cleaners insured?", a: "Yes — every cleaner is fully insured and background-checked for your peace of mind." },
  ],

  guaranteeHeading: "Backed by our 100% Satisfaction Guarantee",
  guaranteeBody:
    "Real people. Trained, insured cleaners. Eco-friendly products. If any part of your clean doesn't meet our standards, tell us within 24 hours and we'll return to re-clean it — free.",
};