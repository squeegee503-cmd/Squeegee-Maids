import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  MapPin, Phone, ShieldCheck, Sparkles, Star, Check, ArrowRight, Award, Clock,
  ChevronDown, CheckCircle2,
} from "lucide-react";
import logoAsset from "@/assets/sm/logo.svg.asset.json";
import heroImgAsset from "@/assets/sm/banner.png.asset.json";
import ceramicImgAsset from "@/assets/sm/after.jpg.asset.json";
import teamImgAsset from "@/assets/sm/commercial.png.asset.json";
import { site } from "@/config/site";

export const Route = createFileRoute("/")({
  component: Index,
});

function Logo({ variant = "light" }: { variant?: "light" | "dark" }) {
  return (
    <a href="#top" className="flex items-center">
      <img
        src={logoAsset.url}
        alt={`${site.brandName} ${site.brandTagline}`}
        className={`h-10 sm:h-12 w-auto ${variant === "light" ? "brightness-0 invert" : ""}`}
      />
    </a>
  );
}

function Nav() {
  return (
    <header className="absolute top-0 inset-x-0 z-30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <Logo />
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-white/85">
          <a href="#top" className="hover:text-white transition">Home</a>
          <a href="#services" className="hover:text-white transition">Services</a>
          <a href="#area" className="hover:text-white transition">Service Area</a>
          <a href="#quote" className="hover:text-white transition">Quote</a>
        </nav>
        <div className="flex items-center gap-3 sm:gap-5">
          <a href={site.phoneHref} className="hidden sm:inline-flex items-center gap-2 text-white/90 hover:text-white text-sm font-medium">
            <Phone className="h-4 w-4" /> {site.phone}
          </a>
          <a href="#quote" className="inline-flex items-center rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30 hover:brightness-110 transition">
            Get Free Quote
          </a>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-[color:var(--ink)] text-white">
      <div className="absolute inset-0">
        <img src={heroImgAsset.url} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-[color:var(--ink)] via-[color:var(--ink)]/80 to-transparent" />
      </div>
      <Nav />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-4 pt-32 pb-16 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:px-8 lg:pt-40 lg:pb-24">
        <div className="flex flex-col justify-center">
          <span className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1 text-xs font-medium uppercase tracking-wider text-white/80 backdrop-blur">
            <MapPin className="h-3.5 w-3.5" /> {site.heroBadge}
          </span>
          <h1 className="mt-5 font-display text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">
            {site.heroTitleA}{" "}
            <span className="bg-gradient-to-r from-primary to-[color:var(--rose-soft)] bg-clip-text text-transparent">
              {site.heroTitleB}
            </span>
          </h1>
          <p className="mt-5 max-w-xl text-lg text-white/80">{site.heroSub}</p>
          <ul className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-white/75">
            {site.heroBullets.map((b, i) => (
              <li key={i} className="flex items-center gap-1.5">
                <Check className="h-4 w-4 text-primary" /> {b}
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#quote" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-xl shadow-primary/30 hover:brightness-110 transition">
              Get My Free Quote <ArrowRight className="h-4 w-4" />
            </a>
            <a href={site.phoneHref} className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-6 py-3 font-semibold text-white backdrop-blur hover:bg-white/10 transition">
              <Phone className="h-4 w-4" /> Call or text {site.phone}
            </a>
          </div>
        </div>
        <QuoteForm dark />
      </div>
    </section>
  );
}

function QuoteForm({ dark }: { dark?: boolean }) {
  const [submitted, setSubmitted] = useState(false);
  return (
    <form
      id="quote"
      onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
      className={`rounded-2xl p-6 sm:p-8 shadow-2xl ${dark ? "bg-white text-foreground" : "bg-card"}`}
    >
      <h2 className="text-2xl font-bold font-display">Get Your Free Quote</h2>
      <p className="mt-1 text-sm text-muted-foreground">Takes 60 seconds. Upfront pricing, no obligation.</p>

      {submitted ? (
        <div className="mt-6 rounded-xl bg-primary/10 p-6 text-center">
          <CheckCircle2 className="mx-auto h-10 w-10 text-primary" />
          <p className="mt-3 font-semibold">Thanks! We'll text you shortly.</p>
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          <Field label="Name" required><input required className="input" placeholder="Your full name" /></Field>
          <Field label="Phone" required><input required type="tel" className="input" placeholder="(503) 555-0100" /></Field>
          <Field label="City or ZIP" required><input required className="input" placeholder="Portland / 97214" /></Field>
          <Field label="Service interested in">
            <select className="input">
              <option>Select…</option>
              <option>Residential Cleaning</option>
              <option>Airbnb Turnover</option>
              <option>Move-In / Move-Out</option>
              <option>Commercial / Office</option>
              <option>One-Time Deep Clean</option>
              <option>Not sure</option>
            </select>
          </Field>
          <button className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/30 hover:brightness-110 transition">
            Get My Free Quote <ArrowRight className="h-4 w-4" />
          </button>
          <p className="text-center text-sm text-muted-foreground">
            Prefer to talk? <a href={site.phoneHref} className="text-primary font-semibold">Call or text {site.phone}</a>
          </p>
        </div>
      )}
    </form>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label} {required && <span className="text-primary">*</span>}
      </span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function TrustBar() {
  const icons = [ShieldCheck, Award, Sparkles, Clock];
  return (
    <section className="bg-secondary border-y border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        {site.trustBar.map((t, i) => {
          const Icon = icons[i];
          return (
            <div key={t} className="flex items-center gap-3 text-sm font-medium">
              <Icon className="h-5 w-5 text-primary" /> {t}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function Eyebrow({ children }: { children: React.ReactNode }) {
  return <p className="text-center text-xs font-bold uppercase tracking-[0.3em] text-primary">{children}</p>;
}

function Reviews() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>Social Proof</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.reviewsHeading}</h2>
        <div className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <div className="flex text-primary">
            {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
          </div>
          <span className="font-semibold text-foreground">{site.reviewsRating}</span>
          <span>· {site.reviewsCount}</span>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {site.reviews.map((r, i) => (
            <blockquote key={i} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <div className="flex text-primary mb-3">
                {[...Array(5)].map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="text-foreground/90 leading-relaxed">"{r.quote}"</p>
              <footer className="mt-4 text-sm font-semibold">{r.name} <span className="text-muted-foreground font-normal">· Google review</span></footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="py-20 sm:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>{site.servicesEyebrow}</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.servicesHeading}</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {site.services.map((s) => (
            <div key={s.title} className={`relative rounded-2xl bg-card p-8 shadow-sm border ${s.badge ? "border-primary shadow-xl shadow-primary/10" : "border-border"}`}>
              {s.badge && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary-foreground">{s.badge}</span>
              )}
              <h3 className="font-display text-2xl font-bold">{s.title}</h3>
              <p className="mt-2 text-muted-foreground">{s.desc}</p>
              <ul className="mt-6 space-y-3">
                {s.bullets.map((b) => (
                  <li key={b} className="flex gap-2 text-sm">
                    <Check className="h-5 w-5 flex-none text-primary" /> {b}
                  </li>
                ))}
              </ul>
              <a href="#quote" className="mt-6 inline-flex w-full items-center justify-center rounded-full bg-primary px-5 py-2.5 font-semibold text-primary-foreground hover:brightness-110 transition">Get a Quote</a>
            </div>
          ))}
        </div>
        <p className="mt-10 text-center text-muted-foreground max-w-3xl mx-auto">
          {site.servicesFooter} <a href="#quote" className="text-primary font-semibold">See all services →</a>
        </p>
      </div>
    </section>
  );
}

function Steps() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>{site.stepsEyebrow}</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.stepsHeading}</h2>
        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {site.steps.map((s) => (
            <div key={s.n} className="relative">
              <div className="font-display text-6xl font-bold text-primary/20">{s.n}</div>
              <h3 className="mt-2 font-display text-2xl font-bold">{s.title}</h3>
              <p className="mt-2 text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Ceramic() {
  return (
    <section className="relative overflow-hidden bg-[color:var(--ink)] text-white py-20 sm:py-28">
      <div className="absolute inset-0">
        <img src={ceramicImgAsset.url} alt="" className="h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-r from-[color:var(--ink)] via-[color:var(--ink)]/70 to-transparent" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-[color:var(--rose-soft)]">{site.ceramicEyebrow}</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight">
            {site.ceramicHeading.split("10 Days")[0]}
            <span className="bg-gradient-to-r from-primary to-[color:var(--rose-soft)] bg-clip-text text-transparent">10 Days or More.</span>
          </h2>
          <p className="mt-5 text-white/80">{site.ceramicBody}</p>
          <ul className="mt-6 space-y-2 text-white/90">
            {site.ceramicBullets.map((b) => (
              <li key={b} className="flex gap-2"><Check className="h-5 w-5 text-primary flex-none" /> {b}</li>
            ))}
          </ul>
          <a href="#quote" className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-xl shadow-primary/30 hover:brightness-110 transition">
            Get My Free Quote <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}

function WhyUs() {
  return (
    <section className="py-20 sm:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>{site.whyEyebrow}</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.whyHeading}</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {site.whyItems.map((w) => (
            <div key={w.title} className="rounded-2xl bg-card p-6 border border-border">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Sparkles className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-xl font-bold">{w.title}</h3>
              <p className="mt-2 text-muted-foreground text-sm">{w.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <a href="#quote" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground hover:brightness-110 transition">
            Get My Free Quote <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}

function ServiceArea() {
  return (
    <section id="area" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>{site.areaEyebrow}</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold max-w-3xl mx-auto">{site.areaHeading}</h2>
        <p className="mt-4 text-center text-muted-foreground max-w-2xl mx-auto">{site.areaBody}</p>
        <div className="mt-10 flex flex-wrap justify-center gap-2 max-w-4xl mx-auto">
          {site.areaCities.map((c) => (
            <span key={c} className="rounded-full border border-border bg-card px-3 py-1.5 text-sm">{c}</span>
          ))}
        </div>
        <div className="mt-12 rounded-2xl bg-secondary p-6 sm:p-8 max-w-xl mx-auto text-center">
          <p className="text-xs font-bold uppercase tracking-wider text-primary">Get in Touch</p>
          <p className="mt-2 font-display text-xl font-bold">{site.address.line1}</p>
          <p className="text-muted-foreground">{site.address.line2}</p>
          <p className="text-muted-foreground">{site.address.line3}</p>
          <div className="mt-4 flex justify-center flex-wrap gap-3">
            <a href={site.phoneHref} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
              <Phone className="h-4 w-4" /> Call {site.phone}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="py-20 sm:py-28 bg-secondary">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <Eyebrow>{site.faqEyebrow}</Eyebrow>
        <h2 className="mt-3 text-center font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.faqHeading}</h2>
        <div className="mt-10 space-y-3">
          {site.faqs.map((f, i) => (
            <div key={i} className="rounded-xl border border-border bg-card">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between px-5 py-4 text-left font-semibold"
              >
                {f.q}
                <ChevronDown className={`h-5 w-5 transition ${open === i ? "rotate-180" : ""}`} />
              </button>
              {open === i && <p className="px-5 pb-5 text-muted-foreground">{f.a}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Guarantee() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:px-8 lg:grid-cols-2 items-center">
        <img src={teamImgAsset.url} alt="Our cleaning team" className="rounded-2xl shadow-xl w-full" />
        <div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold">{site.guaranteeHeading}</h2>
          <p className="mt-5 text-muted-foreground text-lg">{site.guaranteeBody}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#quote" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-xl shadow-primary/30 hover:brightness-110 transition">
              Get My Free Quote <ArrowRight className="h-4 w-4" />
            </a>
            <a href={site.phoneHref} className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 font-semibold hover:bg-secondary transition">
              <Phone className="h-4 w-4" /> Call {site.phone}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="py-20 sm:py-28 bg-[color:var(--ink)] text-white">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:px-8 lg:grid-cols-[1fr_1.1fr] items-start">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-[color:var(--rose-soft)]">Free quote · 60 seconds</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight">
            Get Your Free Quote in Under a Minute
          </h2>
          <p className="mt-5 text-white/80">Tell us about your home and we'll send back an exact price. Same-week appointments often available.</p>
          <ul className="mt-6 space-y-2 text-white/90">
            <li className="flex gap-2"><Check className="h-5 w-5 text-primary" /> 100% Satisfaction Guarantee</li>
            <li className="flex gap-2"><Check className="h-5 w-5 text-primary" /> Upfront, transparent pricing</li>
            <li className="flex gap-2"><Check className="h-5 w-5 text-primary" /> Insured & background-checked cleaners</li>
          </ul>
          <p className="mt-8 text-sm text-white/70">Prefer to talk?</p>
          <a href={site.phoneHref} className="mt-2 inline-flex items-center gap-2 text-xl font-bold text-white">
            <Phone className="h-5 w-5 text-primary" /> {site.phone}
          </a>
        </div>
        <QuoteForm dark />
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-[color:var(--ink)] text-white/60 border-t border-white/10 py-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4 text-sm">
        <Logo />
        <p>© {new Date().getFullYear()} {site.brandName} {site.brandTagline}. All rights reserved.</p>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <style>{`
        .input {
          width: 100%;
          border-radius: 9999px;
          border: 1px solid var(--color-border);
          background: var(--color-background);
          padding: 0.65rem 1rem;
          font-size: 0.95rem;
          color: var(--color-foreground);
          outline: none;
          transition: border-color .15s, box-shadow .15s;
        }
        .input:focus { border-color: var(--color-primary); box-shadow: 0 0 0 3px color-mix(in oklab, var(--color-primary) 20%, transparent); }
      `}</style>
      <main>
        <Hero />
        <TrustBar />
        <Reviews />
        <Services />
        <Steps />
        <Ceramic />
        <WhyUs />
        <ServiceArea />
        <FAQ />
        <Guarantee />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}